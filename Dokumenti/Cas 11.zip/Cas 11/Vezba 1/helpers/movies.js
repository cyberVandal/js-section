exports.create = function( title, year) {
    this.title = title;
    this.year = year;
}