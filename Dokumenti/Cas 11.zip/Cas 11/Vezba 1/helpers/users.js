exports.create = function(name, email, pass, type) {
    this.name = name;
    this.email = email;
    this.pass = pass;
    this.type = type;
}